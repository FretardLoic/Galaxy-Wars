<!DOCTYPE html>
<html>
<head>
	<title>GalaxWar</title>
	<meta charset="utf-8" />
	<meta name="generator" content="Geany 1.27" />
  <link rel="stylesheet" href="style1.css"/>
</head>

<body>
  <form method="GET" action="name_enter.php">
    <p>
      Nombre de joueurs :<input type="number" name="playersNb" value="1" min="1" max="20"/><br />
      Nombre d'ia :<input type="number" name="aiNb" value="0" min="0" max="20"/><br />
      Nombre de planétes :<input type="number" name="planetsNb" value="10" min="1"/><br />
      <input type="submit" value="valider" />
    </p>
  </form>
      
</body>
